Thanks for buying this plugin,

Please note that this resource pack is not allowed to be contributed or sold without permission of the creators.
Contact Creatos on discord: Creatos#6143